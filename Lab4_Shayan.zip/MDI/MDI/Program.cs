/// <summary>
/// Lab 4 MDI Application 
/// Author: Shayan Zahedanaraki
/// Date: February 18, 2023; Revision: -
/// </summary>

namespace MDI
{
    internal static class Program
    {
        /// <summary>
        ///  The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            // To customize application configuration such as set high DPI settings or default font,
            // see https://aka.ms/applicationconfiguration.
            ApplicationConfiguration.Initialize();
            Application.Run(new Form1());
        }
    }
}