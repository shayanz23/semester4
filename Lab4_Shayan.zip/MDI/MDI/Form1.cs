using System.Net;

/// <summary>
/// Lab 4 MDI Application 
/// Author: Shayan Zahedanaraki
/// Date: February 18, 2023; Revision: -
/// </summary>

namespace MDI
{
    public partial class Form1 : Form
    {

        /// <summary>
        /// Default constructor
        /// </summary>
        public Form1()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Event handler for the clicking of the new menu item.
        /// Creates a new blue rectangle with a specified size chosen in a dialog and displays it
        /// in a child MDI window.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void newMenuItem_Click(object sender, EventArgs e)
        {
            using (NewImageDialog newImageDialog = new NewImageDialog())
            {
                if (newImageDialog.ShowDialog() == DialogResult.OK)
                {
                    int option = newImageDialog.SelectedRes;
                    int width;
                    int height;
                    if (option == 2)
                    {
                        height = 600;
                        width = 800;
                    }
                    else if (option == 3)
                    {
                        height = 768;
                        width = 1024;
                    }
                    else
                    {
                        height = 480;
                        width = 640;
                    }
                    Image image = new Bitmap(width, height);
                    Graphics g = Graphics.FromImage(image);
                    MDIChild mDIChild = new MDIChild();
                    mDIChild.MdiParent = this;
                    SolidBrush blueBrush = new SolidBrush(Color.Blue);
                    mDIChild.Size = new Size(width+10, height+10);
                    Rectangle rect = new Rectangle(0, 0, width, height);
                    g.FillRectangle(blueBrush, rect);
                    mDIChild.image = image;
                    mDIChild.Show();
                }
            }
        }

        /// <summary>
        /// Event handler for the clicking of the exit menu item.
        /// Closes the program.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void exitMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }

        /// <summary>
        /// Event handler for the clicking of the open from file menu item.
        /// Opens an image file chosen in OpenFileDialog.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void openFromFileMenuItem_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog openFileDialog = new OpenFileDialog())
            {
                openFileDialog.Filter = "Images|*.jpg;*.jpeg;*.png;*.gif";
                
                if (openFileDialog.ShowDialog(this) == DialogResult.OK)
                {
                    Image image = new Bitmap(openFileDialog.FileName);
                    MDIChild mDIChild = new MDIChild();
                    mDIChild.image = image;
                    mDIChild.MdiParent = this;
                    mDIChild.Show();
                }
            }
        }

        /// <summary>
        /// Event handler for the clicking of the save and saveas menu items.
        /// Saves the image in the currently active MDIChild using a SaveFileDialog.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void saveMenuItem_Click(object sender, EventArgs e)
        {
            using (SaveFileDialog saveFileDialog1 = new SaveFileDialog())
            {
                saveFileDialog1.Filter = "JPEG Image|*.jpg;*.png;*.gif";
                saveFileDialog1.Title = "Save an Image File";
                saveFileDialog1.DefaultExt = ".jpg";
                saveFileDialog1.FileName = "New Image";
                DialogResult result = saveFileDialog1.ShowDialog();
                if (result == DialogResult.OK && ActiveMdiChild != null)
                {
                    MDIChild mDIChild = (MDIChild)ActiveMdiChild;
                    mDIChild.image.Save(saveFileDialog1.FileName, System.Drawing.Imaging.ImageFormat.Jpeg);
                } 
                else if (result == DialogResult.OK && ActiveMdiChild == null)
                {
                    MessageBox.Show("No Image open.","Error",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
                }
            }
        }

        /// <summary>
        /// Event handler for the clicking of the open from web menu item.
        /// Gets an image from a URL and displays it in a MDIChild.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void openFromWebToolStripMenuItem_Click(object sender, EventArgs e)
        {
            using (ImageFromWebDialog openFileDialog = new ImageFromWebDialog())
            {
                if (openFileDialog.ShowDialog(this) == DialogResult.OK)
                {
                    try 
                    {
                        WebClient client = new WebClient();
                        byte[] data = client.DownloadData(openFileDialog.Url);
                        MemoryStream ms = new MemoryStream(data);
                        Image image = Image.FromStream(ms);
                        MDIChild mDIChild = new MDIChild();
                        mDIChild.image = image;
                        mDIChild.MdiParent = this;
                        mDIChild.Show();
                    } 
                    catch (WebException exception) 
                    {
                        MessageBox.Show(exception.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }

        /// <summary>
        /// Event handler for the clicking of the open from cascade menu item.
        /// Cascades MDI children that are open.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>        
        private void cascadeMenuItem_Click(object sender, EventArgs e)
        {
            LayoutMdi(MdiLayout.Cascade);
        }

        /// <summary>
        /// Event handler for the clicking of the open from cascade menu item.
        /// Tiles horizontally MDI children that are open.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void tileHorizontalMenuItem_Click(object sender, EventArgs e)
        {
            LayoutMdi(MdiLayout.TileHorizontal);
        }

        /// <summary>
        /// Event handler for the clicking of the open from cascade menu item.
        /// Tiles Vertically MDI children that are open.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void tileVerticalMenuItem_Click(object sender, EventArgs e)
        {
            LayoutMdi(MdiLayout.TileVertical);
        }

        /// <summary>
        /// Event handler for the clicking of the File menu item.
        /// Checks to see if there is MdiChildren and decides whether to enable
        /// or disable the save and save as menus buttons.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void fileToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (MdiChildren != null && MdiChildren.Length != 0)
            {
                saveAsMenuItem.Enabled = true;
                saveMenuItem.Enabled = true;
            }
            else
            {
                saveAsMenuItem.Enabled = false;
                saveMenuItem.Enabled = false;
            }
        }
    }
}