﻿

namespace MDI
{
    public partial class MDIChild : Form
    {


        /// <summary>
        /// Image property to set and get an image to be displayed by MDI children.
        /// </summary>
        public Image image { get; set; }

        /// <summary>
        /// Constructor with the AutoScroll set to true, which does not work unfortunately.
        /// </summary>
        public MDIChild()
        {
            InitializeComponent();
            AutoScroll = true;
        }

        /// <summary>
        /// This is the paint event handler that uses PaintEventArgs e's Grpahics to draw the image property. 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void MDIChild_Paint(object sender, PaintEventArgs e)
        {
            e.Graphics.DrawImage(image, new Point(0, 0));
        }
    }
}
